const express = require('express');
const session = require('express-session');
const path = require('path');
const cors = require('cors');
const mongoose = require('mongoose');
const flash = require("connect-flash");
const cron = require('node-cron');
const { connectMongoDb } = require('./connect');
const Recaptcha = require("express-recaptcha").RecaptchaV2;
const app = express();
const port = process.env.PORT || 8000;
const tokens = process.env.token || 'admin@129'
const jwt = require('jsonwebtoken');

connectMongoDb();

// session
app.use(session({
  secret: tokens,
  resave: false,
  saveUninitialized: false,
}));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());
app.use(flash());
app.use(function (req, res, next) {
  res.locals.success_msg = req.flash("success_msg");
  res.locals.warning_msg = req.flash("warning_msg");
  res.locals.error_msg = req.flash("error_msg");
  res.locals.error = req.flash("error");
  res.locals.user = req.user || null;
  next();
});


app.set('views', __dirname + '/views')
app.set('public', __dirname + '/public')
app.set('view engine', 'ejs');

// recaptha
const { recaptchaKey, jwtToken } = require("./settings");

const recaptcha = new Recaptcha(recaptchaKey.v2SiteKey, recaptchaKey.v2SecretKey, {
  "hl": "id",
  "callback": "cb"
});

function logout(req) {
  // Hapus token dari session
  delete req.session.token;

  // Tambahkan pesan sukses menggunakan flash
  req.flash('success_msg', 'Logout berhasil');
}

function authenticateSession(req, res, next) {
  const token = req.session.token;

  if (!token) {
    // Tambahkan pesan error menggunakan flash
    req.flash('error', 'Sila Log Masuk Untuk Meneruskan');
    
    return res.redirect('/admin/login');
  }

  jwt.verify(token, tokens, (err, user) => {
    if (err) {
      // Tambahkan pesan error menggunakan flash
      req.flash('error', 'Token tidak valid');
      
      return res.redirect('/admin/login');
    }

    req.user = user;
    next(); // Lanjut ke middleware atau handler berikutnya
  });
}

function getFormattedDate() {
  // Buat objek tanggal saat ini
  const currentDate = new Date();

  // Konfigurasikan opsi format tanggal
  const options = {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    timeZone: 'Asia/Kuala_Lumpur',
  };

  // Dapatkan format tanggal dengan menggunakan Intl.DateTimeFormat
  const formattedDate = new Intl.DateTimeFormat('en-US', options).format(currentDate);

  return formattedDate;
}

// Database Model
const visitorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  nombor: { type: String, required: true },
  status: { type: String, required: true },
  code: { type: String, default: null },
  ic: { type: String, default: null },  // Set default value to null
});

visitorSchema.statics.getTotalUsers = async function() {
  try {
    // Mengira jumlah keseluruhan pengguna dalam pangkalan data
    const totalUsers = await this.countDocuments({});
    return totalUsers;
  } catch (error) {
    throw new Error('Ralat mendapatkan jumlah keseluruhan pengguna: ' + error.message);
  }
};

const Visitor = mongoose.model('Reseller', visitorSchema);

const scammerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  nombor: { type: String, required: true },
  alasan: { type: String, required: true },
});

const Scam = mongoose.model('Scammer', scammerSchema);

async function contoh() {
  try {
    const totalUsers = await Visitor.getTotalUsers();
    return totalUsers
  } catch (error) {
    console.error('Ralat:', error);
  }
}

// model admin
const adminSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

const Admin = mongoose.model('Admin', adminSchema);

// Routes
app.get('/', async (req, res) => {
  const listuser = await contoh()
  res.render('pages/dashboard', {
  user: listuser,
  });
});

app.get('/about', async (req, res) => {
  res.render('pages/about');
});

app.get('/sponsor', async (req, res) => {
  res.render('pages/sponsor');
});

app.get('/admin/info', authenticateSession, async (req, res) => {
  res.render('pages/listadmin');
});

app.get('/contact', async (req, res) => {
  res.render('pages/contact');
});

app.get(`/admin/pages`, authenticateSession, async (req, res) => {
  res.render('pages/admin');
});

app.get('/admin/login', async (req, res) => {
  res.render('pages/login');
});

app.get('/admin/add',  authenticateSession, async (req, res) => {
  res.render('pages/added');
});

app.get('/scammer/add',  authenticateSession, async (req, res) => {
  res.render('pages/addscammer');
});

app.get('/scammer/delete',  authenticateSession, async (req, res) => {
  res.render('pages/delscammer');
});

app.get('/admin/delete',  authenticateSession, async (req, res) => {
  res.render('pages/delete');
});


app.get('/reseller/check', async (req, res) => {
  res.render('pages/check');
});

app.get('/reseller/edit', authenticateSession, async (req, res) => {
  res.render('pages/edit');
});

app.get('/reseller/list', async (req, res) => {
  res.render('pages/listreseller');
});

app.get('/scammer/list', async (req, res) => {
  res.render('pages/listscammer');
});

app.get('/reseller/add', authenticateSession, async (req, res) => {
  res.render('pages/reseller');
});

app.get('/reseller/del', authenticateSession, async (req, res) => {
  res.render('pages/del');
});

app.get('/reseller/database', authenticateSession, async (req, res) => {
  res.render('pages/database');
});

app.get('/reseller/detail', (req, res) => {
  // Akses data pengguna dari session
  const userDetail = req.session.userDetail;

  // Hapus data pengguna dari session (opsional, jika ingin membersihkan setelah ditampilkan)
  delete req.session.userDetail;

  // Render halaman "detail" dengan data pengguna
  res.render('pages/detail', { userDetail });
});

// admin add account
app.post('/admin/add', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if admin with provided email already exists
    const existingAdmin = await Admin.findOne({ email });
    if (existingAdmin) {
      req.flash('error', 'Admin with this email already exists');
      return res.redirect('/admin/add');
    }

    // Create a new admin instance
    const newAdmin = new Admin({ email, password });

    // Save the admin to the database
    await newAdmin.save();

    req.flash('success_msg', 'Admin account created successfully');
    res.redirect('/admin/login');
  } catch (error) {
    console.error(error);
    req.flash('error', 'An error occurred');
    return res.redirect('/admin/add');
  }
});

// admin delete account
app.post('/admin/delete', async (req, res) => {
  const { email } = req.body;

  try {
    // Check if admin with provided email exists
    const existingAdmin = await Admin.findOne({ email });
    if (!existingAdmin) {
      req.flash('error', 'Admin with this email does not exist');
      return res.redirect('/admin/delete');
    }

    // Delete the admin from the database
    await Admin.deleteOne({ email });

    req.flash('success_msg', 'Admin account deleted successfully');
    res.redirect('/admin/delete');
  } catch (error) {
    console.error(error);
    req.flash('error', 'An error occurred');
    return res.redirect('/admin/delete');
  }
});



app.post('/users/add', async (req, res) => {
  try {
    const { name, code, nombor, status, ic } = req.body;

    if (!name) {
      req.flash('error', 'Nama reseller diperlukan');
      return res.redirect("/reseller/add");
    }
    if (!nombor) {
      req.flash('error', 'Nombor telefon diperlukan');
      return res.redirect("/reseller/add");
    }
    if (!status) {
      req.flash('error', 'Status reseller diperlukan');
      return res.redirect("/reseller/add");
    }

    // Set nilai default 'null' jika code tidak dimasukkan
    const codeValue = code || null;
    const icValue = ic || null;

    // Buat instance Visitor menggunakan model mongoose
    const newVisitor = new Visitor({
      name,
      code: codeValue,
      nombor,
      status,
      ic: icValue,
    });

    // Simpan pengguna baru ke dalam database
    const savedVisitor = await newVisitor.save();

    req.flash('success_msg', 'Berjaya menambah reseller tersebut untuk detail sila check di list reseller');
    return res.redirect("/reseller/add"); // Berhasil menambahkan pengguna
  } catch (error) {
    console.log(error);
    // Handle error response
  }
});

app.post('/scammer/add', async (req, res) => {
  try {
    const { name, nombor, aduan } = req.body;

    if (!name) {
      req.flash('error', 'Nama Scammer diperlukan');
      return res.redirect("/scammer/add");
    }
    if (!nombor) {
      req.flash('error', 'Nombor telefon diperlukan');
      return res.redirect("/scammer/add");
    }
    if (!aduan) {
      req.flash('error', 'Aduan Scammer diperlukan');
      return res.redirect("/scammer/add");
    }

    // Buat instance Visitor menggunakan model mongoose
    const newScammer = new Scam({
      name,
      alasan: aduan,
      nombor
    });

    // Simpan pengguna baru ke dalam database
    const savedScammer = await newScammer.save();

    req.flash('success_msg', 'Berjaya menambah scammer tersebut untuk detail sila check di list scammer');
    return res.redirect("/scammer/add"); // Berhasil menambahkan pengguna
  } catch (error) {
    console.log(error);
    req.flash('error', 'An error occurred');
    return res.redirect('/scammer/add');
  }
});

app.post('/scammer/delete', async (req, res) => {
  const { nombor } = req.body;

  try {
    // Check if admin with provided email exists
    const existingAdmin = await Scam.findOne({ nombor });
    if (!existingAdmin) {
      req.flash('error', 'Scammer with this Number does not exist');
      return res.redirect('/scammer/delete');
    }

    // Delete the admin from the database
    await Scam.deleteOne({ nombor });

    req.flash('success_msg', 'Scammer deleted successfully');
    res.redirect('/scammer/delete');
  } catch (error) {
    console.error(error);
    req.flash('error', 'An error occurred');
    return res.redirect('/scammer/delete');
  }
});

app.post('/users/delete', async (req, res) => {
  try {
    const { nombor } = req.body;

    if (!nombor) {
      req.flash('error', "Nombor Reseller diperlukan.");
      return res.redirect("/reseller/del");
    }

    // Cari pengguna berdasarkan nama dan IC
    const deletedUser = await Visitor.findOneAndDelete({ nombor });

    if (!deletedUser) {
      req.flash('error', "Reseller tidak ditemukan.");
      return res.redirect("/reseller/del");
    }

    req.flash('success_msg', "Reseller berhasil dihapus.");
    return res.redirect("/reseller/del");
  } catch (error) {
    console.error(error);
    req.flash('error', "Terjadi kesalahan saat menghapus reseller.");
    return res.redirect("/reseller/del");
  }
});

// Route untuk mengedit data pengunjung berdasarkan nomor
app.post('/users/edit', async (req, res) => {
  try {
    const { name, code, nombor, number, status } = req.body;

    // Periksa apakah nomor telepon disertakan
    if (!number) {
      req.flash('error', 'Nombor telepon diperlukan untuk mengedit reseller');
      return res.redirect("/reseller/edit"); // Redirect ke halaman daftar pengguna
    }

    const user = await Visitor.findOne({ nombor: number });

    // Buat objek update berdasarkan input pengguna
    const updateData = {
      name: name || user.name,
      status: status || user.status,
      nombor: nombor || user.nombor,
      code: code || user.code,
    };

    if (Object.keys(updateData).length === 0) {
      req.flash('error', 'Pilih setidaknya satu bidang untuk diperbarui');
      return res.redirect("/reseller/edit"); // Redirect ke halaman daftar pengguna
    }

    // Temukan pengguna berdasarkan nomor telepon dan update data pengguna
    const updatedVisitor = await Visitor.findOneAndUpdate({ nombor: number }, updateData, { new: true });

    if (!updatedVisitor) {
      req.flash('error', 'Reseller dengan nombor telepon tersebut tidak ditemukan');
      return res.redirect("/reseller/edit"); // Redirect ke halaman daftar pengguna
    }

    req.flash('success_msg', 'Data reseller berhasil diperbarui');
    return res.redirect("/reseller/edit"); // Redirect ke halaman daftar pengguna
  } catch (error) {
    console.error(error);
    req.flash('error', 'Terjadi kesalahan saat mengedit pengguna');
    return res.redirect('/reseller/edit'); // Redirect ke halaman daftar pengguna
  }
});

app.post('/users/search', async (req, res) => {
  try {
    const { nombor } = req.body;

    // Pastikan nomor telepon disertakan dalam body request
    if (!nombor) {
      req.flash('error', 'nombor telefon di perlukan');
      return res.redirect("/reseller/check");
    }

    const scammer = await Scam.findOne({ nombor });

    if (scammer) {
      req.flash('error', 'Nombor ini adalah nombor scammer untuk detail nya sila check di list scammer');
      return res.redirect("/reseller/check");
    }

    // Cari pengguna berdasarkan nomor telepon
    const user = await Visitor.findOne({ nombor });

    if (!user) {
      req.flash('error', 'Reseller belum terdaftar di dalam database, sila berhati-hati sebelum jual beli account');
      return res.redirect("/reseller/check");
    }

    // Simpan data pengguna dalam session
    req.session.userDetail = user;

    // Redirect ke halaman detail
    return res.redirect("/reseller/detail");
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post('/admin/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const admin = await Admin.findOne({ email });

    if (!admin || admin.password !== password) {
      req.flash('error', 'Invalid email or password');
      return res.redirect('/admin/login');
    }

    // Generate token
    const token = jwt.sign({ isAdmin: true }, tokens, { expiresIn: '1d' });

    // Store token in session
    req.session.token = token;

    res.redirect('/admin/pages');
  } catch (error) {
    console.error(error);
    req.flash('error', 'An error occurred');
    return res.redirect('/admin/login');
  }
});

app.get('/admin/logout', (req, res) => {
  logout(req);
  res.redirect('/admin/login');
});

app.get('/user/list', async (req, res) => {
  try {
    // Dapatkan semua pengguna dari database, susun sesuai kebutuhan
    const users = await Visitor.find()

    // Tambahkan nomor indeks pada setiap pengguna
    const usersWithIndex = users.map((user, index) => ({
      index: index + 1,
      ...user.toObject(),
    }));

    res.status(200).json(usersWithIndex);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.get('/admin/list', async (req, res) => {
  try {
    // Dapatkan semua pengguna dari database, susun sesuai kebutuhan
    const users = await Admin.find()

    // Tambahkan nomor indeks pada setiap pengguna
    const usersWithIndex = users.map((user, index) => ({
      index: index + 1,
      ...user.toObject(),
    }));

    res.status(200).json(usersWithIndex);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.get('/user/scammer', async (req, res) => {
  try {
    // Dapatkan semua pengguna dari database, susun sesuai kebutuhan
    const users = await Scam.find()

    // Tambahkan nomor indeks pada setiap pengguna
    const usersWithIndex = users.map((user, index) => ({
      index: index + 1,
      ...user.toObject(),
    }));

    res.status(200).json(usersWithIndex);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
